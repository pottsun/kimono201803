// Zoom
jQuery(document).ready(function(){
    if ($('#detailName img')[0]) {
        $('head').prepend('<script type="text/javascript" src="javascript/iscroll.js"></script>');
		$('#detailImage img').click(function(){
		 	$('#zoomHanger').css('display','block');
		});
		$('#zoomHanger').click(function(){
			$(this).css('display','none');
		});
        $(function(){
            var myScroll = new iScroll('zoomHanger', { zoom: true, zoomMax: 2.0 });
        });
	}
});