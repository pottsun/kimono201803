jQuery(document).ready(function(){
    var agent = navigator.userAgent;
    var count = 0;
    if(agent.search(/Android/) != -1){
		$('h2').css('display','none');
		$('.flickSimple').css('margin-top',50);
    }
});